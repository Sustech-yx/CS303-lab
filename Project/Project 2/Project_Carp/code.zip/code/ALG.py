from time import time
import numpy as npy
import math
import random
from copy import deepcopy


class Solver(object):
    def __init__(self, instance, g, stop_sec=3):
        # only the demand edges are in such list.
        self.edges = {}
        self.cap = instance.capacity
        for index, e in enumerate(instance.r_edge_list):
            self.edges[(e[0], e[1])] = {'cost': e[2], 'dem': e[3]}
            self.edges[(e[1], e[0])] = {'cost': e[2], 'dem': e[3]}
        self.n = len(self.edges.keys())
        self.terminal = int(instance.terminal)
        self.depot = int(instance.depot)
        self.stop_sec = stop_sec
        self.g = g

    def work(self, initial_solution):
        start_time = time()
        state, cost = initial_solution, self.calCost(initial_solution)
        t = 0
        while 1:
            T = 0.99**t
            new_state, new_cost = self.localSearch(state)
            if cost - new_cost > 0:
                state = new_state
                cost = new_cost
            elif random.random() < npy.exp((cost - new_cost) / T):
                state = new_state
                cost = new_cost
            if self.terminal - (time() - start_time) < self.stop_sec:
                break
            t += 1
        return state, cost

    def initialSolution(self):
        result = []
        while len(result) < 50:
            tmp = npy.random.permutation(self.n)
            if tmp not in result:
                result.append(tmp)
        return result

    def localSearch(self, state):
        new_state = deepcopy(state)
        cost = self.calCost(new_state)
        if random.random() < 0.3:  # swap
            temp_swap = None
            for i, route1 in enumerate(state):
                for x, edge1 in enumerate(route1):
                    for j, route2 in enumerate(state):
                        for y, edge2 in enumerate(route2):
                            if not (i == j and x == y):
                                new_state[i][x], new_state[j][y] = new_state[j][y], new_state[i][x]
                                new_cost = self.calCost(new_state)
                                if new_cost < cost:
                                    cost = new_cost
                                    temp_swap = i, x, j, y
                                new_state[i][x], new_state[j][y] = new_state[j][y], new_state[i][x]
            if temp_swap:
                i, x, j, y = temp_swap
                new_state[i][x], new_state[j][y] = new_state[j][y], new_state[i][x]

        else:  # flip
            x = random.randint(0, len(new_state)-1)
            y = random.randint(0, len(new_state[x])-1)
            edge = new_state[x][y]
            edge_ = edge[1], edge[0]
            new_state[x][y] = edge_
        if self.checkValid(new_state):
            return new_state, self.calCost(new_state)
        else:
            return state, self.calCost(state)

    def checkValid(self, sol):
        for route in sol:
            cap = self.cap
            for edge in route:
                cap -= self.edges[edge]['dem']
                if cap < 0:
                    return False
        return True

    def calCost(self, sol):
        res = 0
        for route in sol:
            pointer = self.depot
            for index, edge in enumerate(route):
                res += self.g[pointer-1][edge[0]-1]
                res += self.edges[edge]['cost']
                pointer = edge[1]
                if index == len(route) - 1:
                    res += self.g[pointer - 1][self.depot-1]
                    pointer = self.depot
        return res